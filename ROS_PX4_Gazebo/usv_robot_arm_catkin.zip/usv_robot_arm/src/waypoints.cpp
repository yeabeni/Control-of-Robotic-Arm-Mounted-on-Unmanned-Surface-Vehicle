#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Point.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <std_msgs/Float64.h>

#include <string>
#include "std_msgs/String.h"
#include <std_msgs/Int32.h>
#include <cstddef>
#include <math.h>
#include <vector>
#include <algorithm>
#include <cfloat>
#include <iostream>
#include <Eigen/Geometry>
#include <geometry_msgs/PoseStamped.h>

#include <tf2/LinearMath/Quaternion.h>

// yolov8_ros_msgs
#include <yolov8_ros_msgs/ObjectLocations.h>
#include <yolov8_ros_msgs/Object.h>

bool destin_reached = false;

Eigen::Vector3f vlocal_pos;
Eigen::Vector3f destin;
Eigen::Vector3f destin1;

const float TOLERANCE = 1;       //acceptance radius
std_msgs::Int32 mesg;

tf2::Quaternion quaternion_;

mavros_msgs::State current_state;
void state_cb(const mavros_msgs::State::ConstPtr& msg){
    current_state = *msg;
}

void local_position_cb(const geometry_msgs::PoseStamped::ConstPtr& msg)
{
  vlocal_pos[0] = msg->pose.position.x;
  vlocal_pos[1] = msg->pose.position.y;
  vlocal_pos[2]= msg->pose.position.z; 
}

void detection_cb(const yolov8_ros_msgs::ObjectLocations::ConstPtr& msg)
{
     for (const auto& object : msg->object_location) {
            // Check if the detected object is a "rocket"
            if (object.Class == "rocket") {
                //mode_g = 1; // Set mode_g to 1

                // Assign x, y, and z values to variables
                destin1[0] = 12.3;
                destin1[1] = 0;
                destin1[2] = 0;

                ROS_INFO("Rocket detected! X: %f, Y: %f, Z: %f", destin1[0], destin1[1], destin1[2]);
            }
        }
}

void trajectory(const geometry_msgs::Pose::ConstPtr& msg)
{
                destin[0] = msg->position.x;
                destin[1] = msg->position.y;
                //destin[2] = msg->orientation.w;
                quaternion_.setRPY(0.0,0.0,msg->orientation.w);
                quaternion_ = quaternion_.normalize();

                ROS_INFO("Rocket Position! X: %f, Y: %f, .x: %f, .y: %f, .z: %f, .w: %f", destin[0], destin[1], quaternion_.x(), quaternion_.y(), quaternion_.z(), quaternion_.w());
             
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "usv_navigation_node");
    ros::NodeHandle nh;

    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>
            ("mavros/state", 10, state_cb);
    ros::Subscriber location_sub = nh.subscribe("/yolov8/ObjectLocation", 10, detection_cb);  
    ros::Subscriber simulink_sub = nh.subscribe("/to_ros", 10, trajectory); 

    ros::Subscriber local_pos_sub = nh.subscribe < geometry_msgs::PoseStamped >
    ("mavros/local_position/pose", 100, local_position_cb);
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>
            ("mavros/setpoint_position/local", 10);
    //ros::Publisher pub = nh.advertise<std_msgs::Int32>/("my_topic", 10);
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>
            ("mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>
            ("mavros/set_mode");

    ROS_INFO("Connected");

    //the setpoint publishing rate MUST be faster than 2Hz
    ros::Rate rate(20.0);

    // wait for FCU connection
    while(ros::ok() && !current_state.connected){
        ros::spinOnce();
        rate.sleep();
    }

    geometry_msgs::PoseStamped pose;
    pose.pose.position.x = 15;
    pose.pose.position.y = 0;
    pose.pose.position.z = 0;

    //send a few setpoints before starting
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(pose);
        ros::spinOnce();
        rate.sleep();
    }

    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "OFFBOARD";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time last_request = ros::Time::now();

    while(ros::ok() && !current_state.armed){
        if( current_state.mode != "OFFBOARD" &&
            (ros::Time::now() - last_request > ros::Duration(5.0))){
            if( set_mode_client.call(offb_set_mode) &&
                offb_set_mode.response.mode_sent){
                ROS_INFO("Offboard enabled");
            }
            last_request = ros::Time::now();
        } else {
            if( !current_state.armed &&
                (ros::Time::now() - last_request > ros::Duration(5.0))){
                if( arming_client.call(arm_cmd) &&
                    arm_cmd.response.success){
                    ROS_INFO("Vehicle armed");
                }
                last_request = ros::Time::now();
            }
        }
        local_pos_pub.publish(pose);
        ros::spinOnce();
        rate.sleep();
    }
    
    while(ros::ok() && !destin_reached){    
    pose.pose.position.x = destin[0];
    pose.pose.position.y = destin[1];
    pose.pose.position.z = 0.0; 

    pose.pose.orientation.x = 0.0;
    pose.pose.orientation.y = 0.0;
    pose.pose.orientation.z = 0.0;
    pose.pose.orientation.w = 1.0;

    //pose.pose.orientation.x = quaternion_.x();
    //pose.pose.orientation.y = quaternion_.y();
    //pose.pose.orientation.z = quaternion_.z();
    //pose.pose.orientation.w = quaternion_.w();

    pose.header.stamp = ros::Time::now();
    local_pos_pub.publish(pose);
    ros::spinOnce();
    rate.sleep();          
  }  

    return 0;
}
