#ifndef GAZEBO_ARM_CONTROL_PLUGIN_H
#define GAZEBO_ARM_CONTROL_PLUGIN_H

#include "ros/ros.h"
#include "std_msgs/Float64MultiArray.h"
#include "std_msgs/Bool.h"
#include <sensor_msgs/JointState.h>


#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TwistStamped.h>
#include <mavros_msgs/State.h>
//#include <geometry_msgs/Quaternion.h>
#include <tf/tf.h>


#include <math.h>
#include <stdbool.h>
#include <string>
#include <array>
#include <boost/thread.hpp>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

struct objects_boundbox
{
float  u_c;
float  v_c;
float  u_min;
float  u_max;
float  v_min;
float  v_max;
};
struct objects_bbox
{
vector<objects_boundbox> obj;
}obx;

class RobotArmControl
{
private:
	float vlocal_x = 0.0f;
	float vlocal_y = 0.0f;
	float vlocal_z = 0.0f;

	float vlocal_vx = 0.0f;
	float vlocal_vy = 0.0f;
	float vlocal_vz = 0.0f;

	float actuator_roll = 0.0f; 
  	float actuator_pitch = 0.0f;
  	// float target_dist = 0.0f;

	float const PI = 4.0*atan(1.0);
    float const H = 4.0;
    float const W = 9.0;
    vector<float> llink = {0.09, 0.18, 0.18, 0.18, 0.18, 0.18, 0.0, 0.0}; //LAST TWO ELEMENTS ARE FOR ROLL AND PITCH/YAW
    float const robot_arm_len  = 0.975f;	// ROBOT ARM LENGTH IN (m)	. IT SHOULD BE 0.9715
    //float angle[6] = {90, -90.0, 180.0, 180.0, 180.0, 180.0};
    vector<float> angle = {90, -90.0, 180.0, 180.0, 180.0, 180.0, 0.0, 0.0}; //LAST TWO ELEMENTS ARE FOR ROLL AND PITCH/YAW
    
    float theta_val[10] {0};
    float link_val;
    //float world_space[6] = {};  //CHECK
    //size_t const nlink = sizeof(llink)/sizeof(llink[0]);
    int nlink = llink.size();
    Eigen::Vector3f target_pos{0.5350, 0.0, 0.0};  
    Eigen::Vector3f target{0.0, 0.0, 0.0};  
    bool mission_req = true;
    // bool object_detected = false;
    bool mission_done = false;		//solved - false
    bool engage = false;		//when the target is reachable, deploy robot arm
    uint64_t count = 0;

    int const max_iter = 10000;
    float const err_min = 0.1;  
    
    //READ IN TARGET LOCATION
    // float error_x = 26.0;     //horizontal location of the target
    // float error_y = 0.0;
    float end_targ_mag;
    float rot_ang;
    float cos_rot_ang;
    float sin_rot_ang;
    float z_ct = 36.0;    // vertical location of the target
    //float phi_ct = atan(x_ct/z_ct);  // desired angle of end-effector
    float const fov = 170.0; // (in degree) field of view of FDR-X3000 Sony action camera
	float fcl ; // focal length ( or 23.0 mm) for FDR-X3000 Sony action camera	

    Matrix <float,4,4> mat_transform;    
    Matrix <float,4,4> colmn_mat;		// 
    Matrix <float,4,6> temp_mat;		// COLUMN HAS TO EXTEND TO THE NUMBER OF JOINTS   

    ros::NodeHandle nh_;
	ros::Timer cmdloop_timer_, statusloop_timer_;

	ros::Subscriber vehc_local_pos_sub;
	ros::Subscriber vehc_local_vel_sub;
	ros::Subscriber platform_RP_sub;
	ros::Subscriber target_reach_sub;

	ros::Subscriber vehc_state_sub;	
	ros::Subscriber joint_python_sub;
	// ros::Subscriber bbox_sub;
	
	ros::Publisher joint_ctrl_pub;	

	void CmdLoopCallback(const ros::TimerEvent& event);
	void StatusLoopCallback(const ros::TimerEvent& event);

	void vehc_local_pos_CB(const geometry_msgs::PoseStamped::ConstPtr& msg); 
	void vehc_local_vel_CB(const geometry_msgs::TwistStamped::ConstPtr& msg);

	void PlatformRollPitch_cb(const std_msgs::Float64MultiArray::ConstPtr& msg);
	void target_reachable_cb(const std_msgs::Bool::ConstPtr& msg);

	void vehc_state_CB(const mavros_msgs::State::ConstPtr& msg); 
	//void actuator_control_cb(const mavros_msgs::MountControl::ConstPtr& msg); 
	//void mount_orientation_cb(const geometry_msgs::Quaternion::ConstPtr& msg);  

	void Jointstate_python_cb(const sensor_msgs::JointState::ConstPtr& msg);

	// void boundingbox_callback(const darknet_ros_msgs::BoundingBoxes::ConstPtr& msg);

	void initializeSubPub();	

	void JointPublisher();	

public:
	RobotArmControl(ros::NodeHandle* nodehandle);
	virtual ~RobotArmControl();
};



#endif